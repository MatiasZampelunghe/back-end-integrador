package com.dh.ProyectoIntegrador;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PoyectoIntegradorApplication {

	public static void main(String[] args) {

		SpringApplication.run(PoyectoIntegradorApplication.class, args);
	}

}
