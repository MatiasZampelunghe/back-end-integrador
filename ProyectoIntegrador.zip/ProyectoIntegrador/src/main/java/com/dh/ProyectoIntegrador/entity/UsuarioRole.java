package com.dh.ProyectoIntegrador.entity;

public enum UsuarioRole {
    ROLE_USER,ROLE_ADMIN
}
