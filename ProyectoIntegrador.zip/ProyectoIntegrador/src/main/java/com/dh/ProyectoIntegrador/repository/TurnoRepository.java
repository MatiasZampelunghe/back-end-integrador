package com.dh.ProyectoIntegrador.repository;

import com.dh.ProyectoIntegrador.entity.Turno;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TurnoRepository extends JpaRepository<Turno,Long> {
}
